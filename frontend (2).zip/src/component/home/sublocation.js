import React, { useEffect, useState } from 'react';
import { Box, MenuItem, Stack, Tab, Tabs, TextField, Typography } from '@mui/material';
import NavBar from '../../component/navbar';
import {
    Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale,
    LinearScale,
    BarElement,
    Title
} from 'chart.js';
import { Bar, Pie } from 'react-chartjs-2';
import { useDispatch, useSelector } from 'react-redux';
import { getData, getDefaultData, getNContentData } from '../../store/actions/dataAction';
import { Loader } from '../../component/loader';
import BarGraph from '../barGraph';


ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale,
    LinearScale,
    BarElement,
    Title);


export default function Subloc({location,startDate,endDate}) {

    const { defData, loading } = useSelector((state) => state.data);
    const [barData, setBarData] = useState({
        labels: [],
        datasets: [{
            label: 'subloc Data',
            data: [],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 159, 64, 0.2)',
                'rgba(255, 205, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(201, 203, 207, 0.2)'
            ],
            borderColor: [
                'rgb(255, 99, 132)',
                'rgb(255, 159, 64)',
                'rgb(255, 205, 86)',
                'rgb(75, 192, 192)',
                'rgb(54, 162, 235)',
                'rgb(153, 102, 255)',
                'rgb(201, 203, 207)'
            ],
            borderWidth: 1
        }]
    });
    console.log(defData);


    useEffect(() => {
        if (defData?.subloc?.data) {
            setBarData({
                labels: defData?.subloc?.data && defData?.subloc?.data?.length > 0 ? defData?.subloc?.data[1]?.map((item) => { return item.Date }) : [],
                datasets: [{
                    label: 'subloc Data',
                    data: defData?.subloc?.data && defData?.subloc?.data?.length > 0 ? defData?.subloc?.data[1]?.map((item) => { return item.Count }) : [],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(201, 203, 207, 0.2)'
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)',
                        'rgb(75, 192, 192)',
                        'rgb(54, 162, 235)',
                        'rgb(153, 102, 255)',
                        'rgb(201, 203, 207)'
                    ],
                    borderWidth: 1
                }]
            })
        }
    }, [defData]);






    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(getDefaultData(` [dbo].[GetDateDistributionForALocation]
        @StartDate = ${startDate ? `'${startDate}'` : null}, @EndDate = ${endDate ? `'${endDate}'` : null}, @Continent = ${location?.continent ? `'${location?.continent?.trim()}'` : null}, @Country = ${location?.country ? `'${location?.country?.trim()}'` : null}, @State_or_Province = ${location?.state ? `'${location?.state?.trim()}'` : null}, @Sub_region_1 = ${location?.region ? `'${location?.region?.trim()}'` : null}, @Sub_region_2 = ${location?.region2 ? `'${location?.region2?.trim()}'` : null};
        `, "subloc"));
    }, [dispatch,location,startDate,endDate]);




    return (
        <div>
            <BarGraph defData={defData?.subloc?.data} barData={barData} />


        </div>
    );
}
