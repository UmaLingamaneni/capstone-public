import React, { useEffect, useState } from 'react';
import { Box, Button, Card, Grid, IconButton, ListItemText, Menu, MenuItem, MenuList, Paper, Stack, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TablePagination, TableRow, Tabs, TextField, Typography, styled } from '@mui/material';
import { CSVLink, CSVDownload } from "react-csv";
import NavBar from '../../component/navbar';
import {
    Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale,
    LinearScale,
    BarElement,
    Title
} from 'chart.js';
import { Bar, Pie } from 'react-chartjs-2';
import { useDispatch, useSelector } from 'react-redux';
import { getData, getDefaultData, getNContentData } from '../../store/actions/dataAction';
import { Loader } from '../../component/loader';
import BarGraph from '../barGraph';
import countrys from '../../pages/home/country.json';
import { tableCellClasses } from '@mui/material/TableCell';
import location from '../../pages/home/allcountryjson.json';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import { loadUser } from '../../store/actions/userActions';

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale,
    LinearScale,
    BarElement,
    Title);

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: theme.palette.common.black,
        color: theme.palette.common.white,
    }
}));


export default function CountryTableAllData() {
    const [countryDataAll, setCountryDataAll] = useState([]);
    const [stateDataAll, setStateDataAll] = useState([]);
    const [regionDataAll, setRegionDataAll] = useState([]);
    const [region2DataAll, setRegion2DataAll] = useState([]);



    const [locationData, setLocationData] = useState({});
    const [startDate, setStartDate] = useState(null);
    const [endDate, setEndnData] = useState(null);

    console.log(locationData);

    const { defData, loading } = useSelector((state) => state.data);

    const [page, setPage] = useState(0);


    const dispatch = useDispatch()

    // useEffect(() => {
    //     //     dispatch(getDefaultData(`SELECT * FROM tempdata where REPLACE (CASE 
    //     //     WHEN CHARINDEX('/', Location) > 0 AND CHARINDEX('/', Location, CHARINDEX('/', Location)+1) > 0 
    //     //     THEN SUBSTRING(Location, CHARINDEX('/', Location)+1, CHARINDEX('/', Location, CHARINDEX('/', Location)+1) - CHARINDEX('/', Location) - 1) 
    //     //     ELSE SUBSTRING(Location, CHARINDEX('/', Location)+1, LEN(Location)-1) 
    //     // END,' ','') LIKE '${countryData}';
    //     //         `, "countryAllData"));

    //     console.log(Object.values(locationData).join('/'));
    //     dispatch(getDefaultData(`SELECT * FROM tempdata where Location = '${Object.values(locationData)?.length > 0 ? Object.values(locationData).join('/') : ""}';
    //         `, "countryAllData"));

    // }, [dispatch, locationData]);

    useEffect(() => {
        dispatch(loadUser());
    }, [dispatch]);


    useEffect(() => {
        dispatch(getDefaultData(`EXEC GetCovidDataRowCount @StartDate = ${startDate ? `'${startDate}'` : null}, @EndDate = ${endDate ? `'${endDate}'` : null}, @Continent = ${locationData?.continent ? `'${locationData?.continent?.trim()}'` : null}, @Country = ${locationData?.country ? `'${locationData?.country?.trim()}'` : null}, @State_or_Province = ${locationData?.state ? `'${locationData?.state?.trim()}'` : null}, @Sub_region_1 = ${locationData?.region ? `'${locationData?.region?.trim()}'` : null}, @Sub_region_2 = ${locationData?.region2 ? `'${locationData?.region2?.trim()}'` : null};`, "countryCount"));
        // dispatch(getDefaultData(`EXEC GetCovidData @StartDate = ${startDate ? `'${startDate}'` : null}, @EndDate = ${endDate ? `'${endDate}'` : null}, @Continent = ${locationData?.continent ? `'${locationData?.continent?.trim()}'` : null}, @Country = ${locationData?.country ? `'${locationData?.country?.trim()}'` : null}, @State_or_Province = ${locationData?.state ? `'${locationData?.state?.trim()}'` : null}, @Sub_region_1 = ${locationData?.region ? `'${locationData?.region?.trim()}'` : null}, @Sub_region_2 = ${locationData?.region2 ? `'${locationData?.region2?.trim()}'` : null}, @pageSize = 10000000 ,@pageNumber = ${1};`, "countryAllDataCSV"));

    }, [locationData]);




    useEffect(() => {
        if (page >= 1) {
            dispatch(getDefaultData(`EXEC GetCovidData @StartDate = ${startDate ? `'${startDate}'` : null}, @EndDate = ${endDate ? `'${endDate}'` : null}, @Continent = ${locationData?.continent ? `'${locationData?.continent?.trim()}'` : null}, @Country = ${locationData?.country ? `'${locationData?.country?.trim()}'` : null}, @State_or_Province = ${locationData?.state ? `'${locationData?.state?.trim()}'` : null}, @Sub_region_1 = ${locationData?.region ? `'${locationData?.region?.trim()}'` : null}, @Sub_region_2 = ${locationData?.region2 ? `'${locationData?.region2?.trim()}'` : null}, @pageSize = 10 ,@pageNumber = ${page + 1};`, "countryAllData"));
        }
    }, [page]);

    console.log(defData);


    const handleChangePage = React.useCallback(
        (event, newPage) => {
            setPage(newPage);



            // Avoid a layout jump when reaching the last page with empty rows.

        },
        [],
    );


    return (
        <Grid container spacing={1}>
            <Grid item xs={12} md={12}>
                <Card sx={{ p: 3 }}>

                    <Stack direction="row" spacing={3}>

                        <TextField
                            id="standard-select-currency-native"
                            select
                            label="Continent"

                            fullWidth
                            variant="outlined"
                            onChange={(e) => {


                                setCountryDataAll(location?.filter((item) => item.continent == e.target.value)[0]?.country);
                                setLocationData({ continent: e.target.value });
                            }}
                        >
                            {location?.map((item) => {
                                return (
                                    <MenuItem value={item?.continent} key={item?.continent}>

                                        {item?.continent}


                                    </MenuItem>
                                )
                            })}
                        </TextField>




                        <TextField
                            id="standard-select-country-native"
                            select
                            label="Country"

                            onChange={(e) => {
                                setStateDataAll(countryDataAll?.filter((item) => item.country == e.target.value)[0]?.state);
                                setLocationData({ continent: locationData?.continent, country: e.target.value });

                            }}
                            fullWidth
                            variant="outlined"
                        >
                            {countryDataAll?.map((countrys) => (
                                <MenuItem value={countrys?.country}>
                                    {countrys?.country}
                                </MenuItem>
                            ))}
                        </TextField>



                        <TextField
                            id="standard-select-state-native"
                            select
                            label="State"

                            onChange={(e) => {

                                setRegionDataAll(stateDataAll?.filter((item) => item.state == e.target.value)[0]?.region);
                                setLocationData({ continent: locationData?.continent, country: locationData?.country, state: e.target.value });


                            }}
                            fullWidth
                            variant="outlined"
                        >
                            {stateDataAll?.map((countrys) => (
                                <MenuItem value={countrys?.state}>
                                    {countrys?.state}
                                </MenuItem>
                            ))}
                        </TextField>






                        <TextField
                            id="standard-select-region-native"
                            select
                            label="Region"

                            onChange={(e) => {

                                setRegion2DataAll(regionDataAll?.filter((item) => item.state == e.target.value)[0]?.region2);
                                setLocationData({ continent: locationData?.continent, country: locationData?.country, state: locationData?.state, region: e.target.value });

                            }}
                            fullWidth
                            variant="outlined"
                        >
                            {regionDataAll?.map((countrys) => (
                                <MenuItem value={countrys?.region}>
                                    {countrys?.region}
                                </MenuItem>
                            ))}
                        </TextField>




                        <TextField
                            id="standard-select-region2-native"
                            select
                            label="Sub Region"

                            onChange={(e) => {

                                setLocationData({ ...locationData, region2: e.target.value });
                            }}
                            fullWidth
                            variant="outlined"
                        >
                            {region2DataAll?.map((countrys) => (
                                <MenuItem value={countrys}>
                                    {countrys}
                                </MenuItem>
                            ))}
                        </TextField>

                        <TextField
                            id="startDate"
                            type="date"
                            label="Start Date"
                            onChange={(e) => {

                                setStartDate(e.target.value);
                            }}
                            fullWidth
                            variant="outlined"
                        />

                        <TextField
                            id="endDate"
                            type="date"
                            label="End Date"
                            onChange={(e) => {

                                setEndnData(e.target.value);
                            }}
                            fullWidth
                            variant="outlined"
                        />
                        <Button sx={{ mt: 3 }} fullWidth variant='contained' onClick={() => {
                            dispatch(getDefaultData(`EXEC GetCovidData @StartDate = ${startDate ? `'${startDate}'` : null}, @EndDate = ${endDate ? `'${endDate}'` : null}, @Continent = ${locationData?.continent ? `'${locationData?.continent?.trim()}'` : null}, @Country = ${locationData?.country ? `'${locationData?.country?.trim()}'` : null}, @State_or_Province = ${locationData?.state ? `'${locationData?.state?.trim()}'` : null}, @Sub_region_1 = ${locationData?.region ? `'${locationData?.region?.trim()}'` : null}, @Sub_region_2 = ${locationData?.region2 ? `'${locationData?.region2?.trim()}'` : null}, @pageSize = 10,@pageNumber = 1;`, "countryAllData"));
                            setPage(0);

                        }}>Apply</Button>
                        {defData?.countryAllDataCSV?.data && defData?.countryAllDataCSV?.data?.length > 0 && <CSVLink data={defData?.countryAllDataCSV?.data}>Download CSV</CSVLink>}
                    </Stack>
                </Card>
                {/* SELECT * FROM tempdata where Location LIKE '${Object.values(locationData)?.length > 0 ? Object.values(locationData).join('/') : ""}% */}

            </Grid>
            <Grid item xs={12} md={12}>
                <Card sx={{ p: 3 }}>
                    {defData?.countryAllData?.data && defData?.countryAllData?.data?.length > 0 && <><TableContainer sx={{ maxHeight: "80vh", borderLeft: "1px solid gray" }}>
                        <Table stickyHeader aria-label="sticky table">
                            <TableHead>
                                <TableRow>

                                    {Object.keys(defData?.countryAllData?.data[0][0])?.filter((row) => row != "AA_Substitutions")?.map((row) => (
                                        <StyledTableCell

                                            align={"left"}
                                        >
                                            {row}
                                        </StyledTableCell>
                                    ))}


                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {defData?.countryAllData?.data[0]?.map((row) => {
                                    return (
                                        <TableRow hover role="checkbox" tabIndex={-1} key={row.code}>
                                            {Object.keys(defData?.countryAllData?.data[0][0])?.filter((row) => row != "AA_Substitutions")?.map((rows) => (
                                                <TableCell

                                                    align={"left"}
                                                >
                                                    {row[rows]}
                                                </TableCell>
                                            ))}
                                        </TableRow>
                                    );
                                })}
                            </TableBody>
                        </Table>
                    </TableContainer>
                        <TablePagination
                            rowsPerPageOptions={[10]}
                            component="div"
                            count={defData?.countryCount?.data[0][0]?.RowCount}
                            rowsPerPage={10}
                            page={page}
                            onPageChange={handleChangePage}
                        // onRowsPerPageChange={handleChangeRowsPerPage}
                        />
                    </>
                    }
                </Card>
            </Grid>
        </Grid>
    );
}
