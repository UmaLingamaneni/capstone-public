import React, { useEffect, useState } from 'react';
import { Box, MenuItem, Stack, Tab, Tabs, TextField, Typography } from '@mui/material';
import NavBar from '../../component/navbar';
import {
    Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale,
    LinearScale,
    BarElement,
    Title
} from 'chart.js';
import { Bar, Pie } from 'react-chartjs-2';
import { useDispatch, useSelector } from 'react-redux';
import { getData, getNContentData } from '../../store/actions/dataAction';
import { Loader } from '../../component/loader';


ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale,
    LinearScale,
    BarElement,
    Title);


function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ p: 3 }}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}



function a11yProps(index) {
    return {
        id: `full-width-tab-${index}`,
        'aria-controls': `full-width-tabpanel-${index}`,
    };
}

export default function N_Content() {

    const { nData, loading } = useSelector((state) => state.data);
    const [barData, setBarData] = useState({
        labels: [],
        datasets: [{
            label: 'Covid Cases Coverage Areas',
            data: [],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 159, 64, 0.2)',
                'rgba(255, 205, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(201, 203, 207, 0.2)'
            ],
            borderColor: [
                'rgb(255, 99, 132)',
                'rgb(255, 159, 64)',
                'rgb(255, 205, 86)',
                'rgb(75, 192, 192)',
                'rgb(54, 162, 235)',
                'rgb(153, 102, 255)',
                'rgb(201, 203, 207)'
            ],
            borderWidth: 1
        }]
    });
    console.log(nData);


    useEffect(() => {
        if (nData?.counts) {
            setBarData({
                labels: ["High Coverage Area", "Low Coverage Area","Total Coverage Area"],
                datasets: [{
                    label: 'Covid Cases Coverage Areas',
                    data: nData?.counts[0]?.map((item) => { return (item?.Count) }),
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(201, 203, 207, 0.2)'
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)',
                        'rgb(75, 192, 192)',
                        'rgb(54, 162, 235)',
                        'rgb(153, 102, 255)',
                        'rgb(201, 203, 207)'
                    ],
                    borderWidth: 1
                }]
            })
        }
    }, [nData]);






    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(getNContentData());
    }, []);



    return (
        <div>


            <Typography variant='h5' textAlign="center" sx={{ mt: 3 }}>
                The Maximum Low Coverage Area Is {nData?.lowCovergeMin && nData?.lowCovergeMin[0]?.MaxNContentwithLowCoverage}
            </Typography>


            {nData?.counts && <Box sx={{ height: "70vh", width: "100%", display: "flex", justifyContent: "center", alignItems: "center" }}>
                <Bar data={barData}
                    options={{
                        maintainAspectRatio: false,
                        datalabels: {
                            display: true,
                            align: 'bottom',
                            borderRadius: 3,
                            font: {
                                size: 18,
                            },
                        }
                    }
                    } />
            </Box>}

        </div>
    );
}
