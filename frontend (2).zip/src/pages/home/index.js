import React, { useEffect, useState } from 'react';
import { Box, Card, Divider, Button, Grid, IconButton, List, ListItem, ListItemButton, ListItemText, MenuItem, Stack, SwipeableDrawer, Tab, Tabs, TextField, Typography } from '@mui/material';
import NavBar from '../../component/navbar';
import {
    Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale,
    LinearScale,
    BarElement,
    Title
} from 'chart.js';
import { Bar, Pie } from 'react-chartjs-2';
import { useDispatch, useSelector } from 'react-redux';
import { Loader } from '../../component/loader';
import MenuIcon from '@mui/icons-material/Menu';
import Variant from '../../component/home/varientnumber';
import TopFiveTotalCase from '../../component/home/top5countrytotalcases';
import CountryTable from '../../component/home/everycountrycasestable';
import GenderCombineVsUnknown from '../../component/home/genderCombineVsUnknown';
import Age from '../../component/home/agenumber';
import Clade from '../../component/home/cladvsnumber';
import Gender from '../../component/home/gendernumber';
import TopFive from '../../component/home/top5data';
import Country from '../../component/home/monthwiseCountryData';
import CountryTableAllData from '../../component/home/countryTable';
import Subloc from '../../component/home/sublocation';
import Pangolium from '../../component/home/pangolium';
import location from './allcountryjson.json';
import N_Content from '../ncontent/ncontent';



ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale,
    LinearScale,
    BarElement,
    Title);



function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ p: 3 }}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}


function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}



export default function Home() {



    const [indexes, setIndexes] = useState(1);


    const { data, loading } = useSelector((state) => state.data);


    const [value, setValue] = React.useState(0);

    const [countryDataAll, setCountryDataAll] = useState([]);
    const [stateDataAll, setStateDataAll] = useState([]);
    const [regionDataAll, setRegionDataAll] = useState([]);
    const [region2DataAll, setRegion2DataAll] = useState([]);



    const [locationData, setLocationData] = useState({});
    const [startDate, setStartDate] = useState(null);
    const [endDate, setEndnData] = useState(null);




    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    const dispatch = useDispatch();



    // useEffect(() => {
    //     console.log([...new Set(location.map((name) => name?.Continent))].map((item) => {
    //         return ({
    //             continent: item,
    //             country: [...new Set(location.filter((countr) => countr?.Continent == item).map((countr) => countr?.Country))].map((countr) => {
    //                 return ({
    //                     country: countr,
    //                     state: [
    //                         ...new Set(location.filter((states) => states?.Country == countr).map((states) => states["Province or State"]))
    //                     ].map((reg) => {
    //                         return ({
    //                             state: reg,
    //                             region: [
    //                                 ...new Set(location.filter((region) => region["Province or State"] == reg).map((region) => region["Subregion-2"]))
    //                             ].map((region2) => {
    //                                 return ({
    //                                     region: region2,
    //                                     region2: [
    //                                         ...new Set(location.filter((reg2) => reg2["Subregion-2"] == region2).map((reg2) => reg2["SubRegion-2"]))
    //                                     ]
    //                                 })
    //                             })
    //                         })
    //                     })
    //                 })
    //             })
    //         })

    //     }))
    // }, [])

    // drawer open

    const [state, setState] = useState(false);

    const toggleDrawer = (anchor, open) => (event) => {
        if (
            event &&
            event.type === 'keydown' &&
            (event.key === 'Tab' || event.key === 'Shift')
        ) {
            return;
        }

        setState(open);
    };






    const list = (anchor) => (
        <Box
            sx={{ width: anchor === 'top' || anchor === 'bottom' ? 'auto' : 250 }}
            role="presentation"
            onClick={toggleDrawer(anchor, false)}
            onKeyDown={toggleDrawer(anchor, false)}
        >
            <List>
                <ListItem onClick={() => {
                    setIndexes(1);
                }} disablePadding>
                    <ListItemButton>

                        <ListItemText primary={"Dashboard"} />
                    </ListItemButton>
                </ListItem>
                <ListItem onClick={() => {
                    setIndexes(2);
                }} disablePadding>
                    <ListItemButton>

                        <ListItemText primary={"Age,Clade,Gender"} />
                    </ListItemButton>
                </ListItem>
                <ListItem onClick={() => {
                    setIndexes(3);
                }} disablePadding>
                    <ListItemButton>

                        <ListItemText primary={"Filters"} />
                    </ListItemButton>
                </ListItem>
                <ListItem onClick={() => {
                    setIndexes(4);
                }} disablePadding>
                    <ListItemButton>

                        <ListItemText primary={"Show Country Data"} />
                    </ListItemButton>
                </ListItem>
            </List>

        </Box>
    );


    return (
        <div>
            <Loader loading={loading} />
            <NavBar />



            <Grid sx={{ justifyContent: "center", alignItems: "center" }} container spacing={4}>

                <Grid item xs={12} sm={4}>

                    <Box sx={{ p: 3 }}>
                        <Typography variant="h5">
                            {value == 0 ? "Corona Virus Dashboard" : value == 1 ? "Corona Virus Varient" : value == 2 ? "Corona Virus With Some Filters" : value == 3 ? "Corona Virus Filters" : ""}

                        </Typography>

                    </Box>
                </Grid>

                <Grid item xs={12} sm={8}>

                    <Tabs value={value} onChange={handleChange} variant="fullWidth" aria-label="basic tabs example">
                        <Tab label="Raw Data" {...a11yProps(0)} />
                        <Tab label="Statistics " {...a11yProps(1)} />
                        <Tab label="Variant,Clade,PangoLineage" {...a11yProps(2)} />
                        <Tab label="N Content " {...a11yProps(3)} />

                    </Tabs>
                </Grid>
            </Grid>

            <TabPanel value={value} index={0}>

                <Box sx={{ my: 5, p: 3 }}>
                    <CountryTableAllData />
                </Box>
            </TabPanel>

            <TabPanel value={value} index={1}>
                <Card sx={{ p: 3 }}>

                    <Stack direction="row" spacing={3}>

                        <TextField
                            id="standard-select-currency-native"
                            select
                            label="Continent"

                            fullWidth
                            variant="outlined"
                            onChange={(e) => {


                                setCountryDataAll(location?.filter((item) => item.continent == e.target.value)[0]?.country);
                                setLocationData({ continent: e.target.value });
                            }}
                        >
                            {location?.map((item) => {
                                return (
                                    <MenuItem value={item?.continent} key={item?.continent}>

                                        {item?.continent}


                                    </MenuItem>
                                )
                            })}
                        </TextField>




                        <TextField
                            id="standard-select-country-native"
                            select
                            label="Country"

                            onChange={(e) => {
                                setStateDataAll(countryDataAll?.filter((item) => item.country == e.target.value)[0]?.state);
                                setLocationData({ continent: locationData?.continent, country: e.target.value });

                            }}
                            fullWidth
                            variant="outlined"
                        >
                            {countryDataAll?.map((countrys) => (
                                <MenuItem value={countrys?.country}>
                                    {countrys?.country}
                                </MenuItem>
                            ))}
                        </TextField>



                        <TextField
                            id="standard-select-state-native"
                            select
                            label="State"

                            onChange={(e) => {

                                setRegionDataAll(stateDataAll?.filter((item) => item.state == e.target.value)[0]?.region);
                                setLocationData({ continent: locationData?.continent, country: locationData?.country, state: e.target.value });


                            }}
                            fullWidth
                            variant="outlined"
                        >
                            {stateDataAll?.map((countrys) => (
                                <MenuItem value={countrys?.state}>
                                    {countrys?.state}
                                </MenuItem>
                            ))}
                        </TextField>






                        <TextField
                            id="standard-select-region-native"
                            select
                            label="Region"

                            onChange={(e) => {

                                setRegion2DataAll(regionDataAll?.filter((item) => item.state == e.target.value)[0]?.region2);
                                setLocationData({ continent: locationData?.continent, country: locationData?.country, state: locationData?.state, region: e.target.value });

                            }}
                            fullWidth
                            variant="outlined"
                        >
                            {regionDataAll?.map((countrys) => (
                                <MenuItem value={countrys?.region}>
                                    {countrys?.region}
                                </MenuItem>
                            ))}
                        </TextField>




                        <TextField
                            id="standard-select-region2-native"
                            select
                            label="Sub Region"

                            onChange={(e) => {

                                setLocationData({ ...locationData, region2: e.target.value });
                            }}
                            fullWidth
                            variant="outlined"
                        >
                            {region2DataAll?.map((countrys) => (
                                <MenuItem value={countrys}>
                                    {countrys}
                                </MenuItem>
                            ))}
                        </TextField>

                        <TextField
                            id="startDate"
                            type="date"
                            label="Start Date"
                            onChange={(e) => {

                                setStartDate(e.target.value);
                            }}
                            fullWidth
                            variant="outlined"
                        />

                        <TextField
                            id="endDate"
                            type="date"
                            label="End Date"
                            onChange={(e) => {

                                setEndnData(e.target.value);
                            }}
                            fullWidth
                            variant="outlined"
                        />

                    </Stack>
                </Card>
                <Grid sx={{ justifyContent: "center", alignItems: "center", my: 4 }} container spacing={4}>
                    <Grid item xs={10} sm={5}>
                        <Card sx={{ p: 3 }}>
                            <Typography variant='body2' sx={{ textAlign: "center" }}>Age Distribution</Typography>
                            <Variant location={locationData} endDate={endDate} startDate={startDate} />
                        </Card>
                    </Grid>
                    <Grid item xs={10} sm={5}>
                        <Card sx={{ p: 3 }}>
                            <Typography variant='body2' sx={{ textAlign: "center" }}>Gender Distribution</Typography>
                            {/* <TopFiveTotalCase /> */}
                            <GenderCombineVsUnknown location={locationData} endDate={endDate} startDate={startDate} />

                        </Card>
                    </Grid>

                    <Grid item xs={10} sm={5}>
                        <Card sx={{ p: 3 }}>
                            <Typography variant='body2' sx={{ textAlign: "center" }}>Host Distribution</Typography>
                            <Age location={locationData} endDate={endDate} startDate={startDate} />

                        </Card>
                    </Grid>
                    <Grid item xs={10} sm={5}>
                        <Card sx={{ p: 3 }}>
                            <Typography variant='body2' sx={{ textAlign: "center" }}>SubLocation Distribution</Typography>
                            <TopFiveTotalCase location={locationData} endDate={endDate} startDate={startDate} />
                        </Card>
                    </Grid>
                    <Grid item xs={10} sm={10}>
                        <Card>
                            <Typography variant='body2' sx={{ textAlign: "center" }}>DateDistributionForALocation</Typography>
                            <Subloc location={locationData} endDate={endDate} startDate={startDate} />
                        </Card>
                    </Grid>
                </Grid>
            </TabPanel>

            <TabPanel value={value} index={2}>
                <Card sx={{ p: 3 }}>

                    <Stack direction="row" spacing={3}>

                        <TextField
                            id="standard-select-currency-native"
                            select
                            label="Continent"

                            fullWidth
                            variant="outlined"
                            onChange={(e) => {


                                setCountryDataAll(location?.filter((item) => item.continent == e.target.value)[0]?.country);
                                setLocationData({ continent: e.target.value });
                            }}
                        >
                            {location?.map((item) => {
                                return (
                                    <MenuItem value={item?.continent} key={item?.continent}>

                                        {item?.continent}


                                    </MenuItem>
                                )
                            })}
                        </TextField>




                        <TextField
                            id="standard-select-country-native"
                            select
                            label="Country"

                            onChange={(e) => {
                                setStateDataAll(countryDataAll?.filter((item) => item.country == e.target.value)[0]?.state);
                                setLocationData({ continent: locationData?.continent, country: e.target.value });

                            }}
                            fullWidth
                            variant="outlined"
                        >
                            {countryDataAll?.map((countrys) => (
                                <MenuItem value={countrys?.country}>
                                    {countrys?.country}
                                </MenuItem>
                            ))}
                        </TextField>



                        <TextField
                            id="standard-select-state-native"
                            select
                            label="State"

                            onChange={(e) => {

                                setRegionDataAll(stateDataAll?.filter((item) => item.state == e.target.value)[0]?.region);
                                setLocationData({ continent: locationData?.continent, country: locationData?.country, state: e.target.value });


                            }}
                            fullWidth
                            variant="outlined"
                        >
                            {stateDataAll?.map((countrys) => (
                                <MenuItem value={countrys?.state}>
                                    {countrys?.state}
                                </MenuItem>
                            ))}
                        </TextField>






                        <TextField
                            id="standard-select-region-native"
                            select
                            label="Region"

                            onChange={(e) => {

                                setRegion2DataAll(regionDataAll?.filter((item) => item.state == e.target.value)[0]?.region2);
                                setLocationData({ continent: locationData?.continent, country: locationData?.country, state: locationData?.state, region: e.target.value });

                            }}
                            fullWidth
                            variant="outlined"
                        >
                            {regionDataAll?.map((countrys) => (
                                <MenuItem value={countrys?.region}>
                                    {countrys?.region}
                                </MenuItem>
                            ))}
                        </TextField>




                        <TextField
                            id="standard-select-region2-native"
                            select
                            label="Sub Region"

                            onChange={(e) => {

                                setLocationData({ ...locationData, region2: e.target.value });
                            }}
                            fullWidth
                            variant="outlined"
                        >
                            {region2DataAll?.map((countrys) => (
                                <MenuItem value={countrys}>
                                    {countrys}
                                </MenuItem>
                            ))}
                        </TextField>

                        <TextField
                            id="startDate"
                            type="date"
                            label="Start Date"
                            onChange={(e) => {

                                setStartDate(e.target.value);
                            }}
                            fullWidth
                            variant="outlined"
                        />

                        <TextField
                            id="endDate"
                            type="date"
                            label="End Date"
                            onChange={(e) => {

                                setEndnData(e.target.value);
                            }}
                            fullWidth
                            variant="outlined"
                        />

                    </Stack>
                </Card>
                <Grid sx={{ justifyContent: "center", alignItems: "center", my: 4 }} container spacing={4}>
                    <Grid item xs={10} sm={5}>
                        <Card sx={{ p: 3 }}>
                            <Typography variant='body2' sx={{ textAlign: "center" }}>Clade Distribution</Typography>
                            <Clade location={locationData} endDate={endDate} startDate={startDate} />
                        </Card>
                    </Grid>
                    <Grid item xs={10} sm={5}>
                        <Card sx={{ p: 3 }}>
                            <Typography variant='body2' sx={{ textAlign: "center" }}>Variant Distribution</Typography>
                            <Gender location={locationData} endDate={endDate} startDate={startDate} />
                        </Card>
                    </Grid>

                    <Grid item xs={10} sm={10}>
                        <Card sx={{ p: 3 }}>
                            <Typography variant='body2' sx={{ textAlign: "center" }}>Pango_lineage Distribution
                            </Typography>
                            <Pangolium location={locationData} endDate={endDate} startDate={startDate} />
                        </Card>
                    </Grid>

                </Grid>
            </TabPanel>


            <TabPanel value={value} index={3}>

                <Grid sx={{ justifyContent: "center", alignItems: "center", my: 4 }} container spacing={4}>
                    <N_Content />



                </Grid>
            </TabPanel>


        </div>
    );
}
