var connection = {
    server: "uma-ualr-2023.database.windows.net",
    port: 1433,
    user: "admin_2023",
    password: 'umacapstone@123',
    database: "Covid_DataBase",
    multipleStatements: true,
    authentication: {
        type: 'default'
    },
    options: {
        encrypt: true
    },
    requestTimeout: 99999999

};



module.exports = connection